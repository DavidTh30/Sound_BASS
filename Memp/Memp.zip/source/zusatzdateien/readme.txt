Diese Archive enthalten f�r das Memp-Tutorial wichtige Zusatz-Dateien.

Das Archiv bass24(parts).zip enth�lt Teile des bass- und basswma-Archivs, das von www.un4seen.com heruntergeladen werden kann.

Die Dateien entpacken und ggf. die Library-Pfade in Delphi anpassen.