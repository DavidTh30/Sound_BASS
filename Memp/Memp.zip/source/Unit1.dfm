object Form1: TForm1
  Left = 1031
  Top = 426
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'MeMP - Mein einfacher mp3-Player'
  ClientHeight = 545
  ClientWidth = 353
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object LblTitel: TLabel
    Left = 8
    Top = 94
    Width = 265
    Height = 13
    AutoSize = False
    Caption = '...'
  end
  object LblTime: TLabel
    Left = 288
    Top = 94
    Width = 33
    Height = 13
    Alignment = taRightJustify
    AutoSize = False
    Caption = '...'
  end
  object SpectrumPaintbox: TPaintBox
    Left = 8
    Top = 8
    Width = 312
    Height = 73
    Color = clActiveCaption
    ParentColor = False
  end
  object BtnPlayPause: TButton
    Left = 96
    Top = 136
    Width = 65
    Height = 21
    Caption = 'Play'
    TabOrder = 1
    OnClick = BtnPlayPauseClick
  end
  object BtnStop: TButton
    Left = 168
    Top = 136
    Width = 65
    Height = 21
    Caption = 'Stop'
    TabOrder = 2
    OnClick = BtnStopClick
  end
  object MainScrollbar: TScrollBar
    Left = 8
    Top = 112
    Width = 313
    Height = 17
    PageSize = 0
    TabOrder = 9
    OnScroll = MainScrollbarScroll
  end
  object VolumeScrollbar: TScrollBar
    Left = 328
    Top = 8
    Width = 17
    Height = 121
    Kind = sbVertical
    PageSize = 0
    TabOrder = 10
    OnScroll = VolumeScrollbarScroll
  end
  object PlaylistView: TListView
    Left = 8
    Top = 184
    Width = 337
    Height = 353
    Columns = <
      item
        Caption = 'Titel'
        Width = 280
      end
      item
        Caption = 'Dauer'
      end>
    TabOrder = 8
    ViewStyle = vsReport
    OnCustomDrawItem = PlaylistViewCustomDrawItem
    OnDblClick = PlaylistViewDblClick
  end
  object BtnAddFiles: TButton
    Left = 8
    Top = 160
    Width = 81
    Height = 21
    Caption = 'Hinzuf'#252'gen'
    TabOrder = 4
    OnClick = BtnAddFilesClick
  end
  object BtnPrev: TButton
    Left = 8
    Top = 136
    Width = 65
    Height = 21
    Caption = 'Zur'#252'ck'
    TabOrder = 0
    OnClick = BtnPrevClick
  end
  object BtnNext: TButton
    Left = 256
    Top = 136
    Width = 65
    Height = 21
    Caption = 'Vor'
    TabOrder = 3
    OnClick = BtnNextClick
  end
  object BtnLoadList: TButton
    Left = 96
    Top = 160
    Width = 65
    Height = 21
    Caption = 'Laden'
    TabOrder = 5
    OnClick = BtnLoadListClick
  end
  object BtnClear: TButton
    Left = 240
    Top = 160
    Width = 81
    Height = 21
    Caption = 'L'#246'schen'
    TabOrder = 7
    OnClick = BtnClearClick
  end
  object BtnSaveList: TButton
    Left = 168
    Top = 160
    Width = 65
    Height = 21
    Caption = 'Speichern'
    TabOrder = 6
    OnClick = BtnSaveListClick
  end
  object MainTimer: TTimer
    Enabled = False
    Interval = 100
    OnTimer = MainTimerTimer
    Top = 120
  end
  object FilesOpenDialog: TOpenDialog
    Options = [ofHideReadOnly, ofAllowMultiSelect, ofEnableSizing]
    Left = 8
    Top = 48
  end
  object PlaylistOpenDialog: TOpenDialog
    Filter = 'M3U-Listen|*.m3u'
    Left = 80
    Top = 48
  end
  object XPManifest1: TXPManifest
    Left = 312
    Top = 48
  end
  object PlaylistSaveDialog: TSaveDialog
    DefaultExt = 'm3u'
    Filter = 'M3U-Listen|*.m3u'
    Left = 112
    Top = 48
  end
end
