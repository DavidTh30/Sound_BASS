program MeMP;

uses
  Forms,
  Unit1 in 'Unit1.pas' {Form1},
  AudioDatei_Klasse in 'AudioDatei_Klasse.pas',
  Player_Klasse in 'Player_Klasse.pas',
  Playlist_Klasse in 'Playlist_Klasse.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
